/*
 * HDF5 C Test for szip filter
 */
#include "H5pubconf.h"

int main()
{
#if H5_HAVE_FILTER_SZIP==1
	return 0;
#else
	XXX;
#endif
}
